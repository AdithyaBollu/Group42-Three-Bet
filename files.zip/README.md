# Poker RL — PPO Agent for Heads-Up Texas Hold'em

A reinforcement-learning poker bot that learns to play No-Limit Texas
Hold'em by playing thousands of hands against a random opponent and
improving its strategy via the PPO algorithm.

---

## Project Structure

```
poker_rl/
├── bot.py          ← PokerBot class  (cash, reward, wins, losses)
├── poker_env.py    ← Gymnasium environment  (wraps PokerKit)
├── train.py        ← PPO training script   (entry point)
├── play.py         ← Load & watch the trained bot play
└── README.md       ← this file
```

---

## Install Dependencies

```bash
pip install pokerkit gymnasium stable-baselines3 torch matplotlib
```

| Package              | Role                                      |
|----------------------|-------------------------------------------|
| `pokerkit`           | Texas Hold'em game engine & hand eval     |
| `gymnasium`          | RL environment interface (step/reset API) |
| `stable-baselines3`  | PPO algorithm (handles the hard RL math)  |
| `torch`              | Neural-network backend for SB3            |
| `matplotlib`         | Plotting the learning curve               |

---

## How to Run

### 1. Train the agent

```bash
python train.py                # 200 000 timesteps (default)
python train.py --steps 500000 # longer run for better results
```

This will:
* Train for the specified number of timesteps
* Print live eval stats every 1 000 steps
* Save the model to `poker_ppo_model.zip`
* Save a learning-curve plot to `learning_curve.png`
* Run a 100-hand post-training evaluation

### 2. Watch the bot play

```bash
python play.py              # 10 hands, default model
python play.py --hands 50   # 50 hands
```

Prints every decision with hole cards, board, pot size, and stacks.

---

## How It All Fits Together

```
┌─────────────┐     step(action)     ┌─────────────────┐
│   PPO Agent │ ──────────────────►  │   PokerEnv      │
│  (neural    │                      │  (poker_env.py) │
│   network)  │ ◄──────────────────  │                 │
└─────────────┘   obs, reward, done  │  uses PokerKit  │
                                     │  for game logic │
                                     └─────────────────┘
                                            │
                                            ▼
                                     ┌─────────────────┐
                                     │   PokerBot      │
                                     │  (bot.py)       │
                                     │  tracks $, wins │
                                     └─────────────────┘
```

### bot.py  –  PokerBot class
Each player is a `PokerBot`.  It holds:
* `cash_val`  – current chip stack (starts at buy-in $75)
* `reward`    – cumulative RL reward (what PPO optimises)
* `wins`  /  `losses`  – hand-level counters for logging

### poker_env.py  –  The Gymnasium Environment
Turns a PokerKit game into the `reset()` / `step()` loop that PPO
expects.  Key responsibilities:
* **Observation** – encodes visible cards + pot + stacks into a
  72-dimensional float vector the neural network can read.
* **Action space** – 6 discrete actions:
  `fold | check | call | raise ¼pot | raise ½pot | raise pot`
* **Legal-action mask** – tells PPO which actions are actually
  allowed right now (e.g. you can't check when there's a bet to
  call).
* **Reward** – `+amount` if the agent wins, `-amount` if it loses.
* **Opponent** – plays randomly so there is always someone to learn
  against.

### train.py  –  PPO Training Loop
Uses Stable-Baselines3's `PPO` class.  The key hyper-parameters:

| Parameter      | Default | What it does                                |
|----------------|---------|---------------------------------------------|
| `n_steps`      | 512     | How many hands before each policy update    |
| `batch_size`   | 64      | Mini-batch size for gradient descent        |
| `n_epochs`     | 10      | How many times to re-use each rollout       |
| `learning_rate`| 3e-4    | Step size for the optimizer                 |
| `gamma`        | 0.99    | Discount factor (how much future $ matters) |
| `clip_range`   | 0.2     | PPO clipping (keeps updates stable)         |
| `ent_coef`     | 0.01    | Entropy bonus (encourages exploration)      |

### play.py  –  Watch It Play
Loads the saved model and runs hands, printing every decision with
full context so you can see what the bot learned.

---

## Game Rules (this project)

| Setting        | Value       |
|----------------|-------------|
| Variant        | No-Limit Texas Hold'em |
| Players        | 2 (heads-up) |
| Buy-in         | $75         |
| Small Blind    | $5          |
| Big Blind      | $10         |
| Actions        | Fold, Check, Call, Raise ¼ pot, Raise ½ pot, Raise pot |

---

## What the Bot Learns (over time)

Early on the bot plays randomly – it folds good hands and calls with
garbage.  As training progresses it starts to learn patterns like:

* Pocket pairs → tend to raise
* Weak hands vs an opponent raise → tend to fold
* Strong flop hits → tend to bet/raise
* Position-awareness (small blind vs big blind in heads-up)

The learning curve plot shows mean reward per hand trending upward
as the policy improves.

---

## Next Steps (ideas)

* **Self-play** – have two PPO agents play each other instead of
  one playing a random opponent.  Much harder to train but produces
  stronger bots.
* **Action masking layer** – feed the legal mask directly into the
  network so it *never* outputs illegal actions.
* **Reward shaping** – reward intermediate good decisions (e.g. a
  well-timed bluff that wins the pot) not just final outcomes.
* **Curriculum learning** – start with simpler situations (e.g. pre-flop
  only) and gradually add complexity.
* **Opponent modelling** – give the agent info about the opponent's
  tendencies so it can exploit them.
```
