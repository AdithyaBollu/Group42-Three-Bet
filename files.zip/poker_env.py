"""
poker_env.py
------------
A Gymnasium-compatible environment that wraps PokerKit's
NoLimitTexasHoldem into a single-agent RL loop.

                ┌──────────────────────────────────┐
                │         PokerEnv                 │
                │                                  │
   reset() ───► │  deal cards                      │
                │  return obs, info                │
                │                                  │
   step(act) ─► │  validate action (legal mask)    │
                │  execute action via PokerKit     │
                │  if hand over → compute reward   │
                │  return obs, reward, done, info  │
                └──────────────────────────────────┘

Design notes
────────────
* The "agent" is always player 0.  Player 1 is a simple random
  opponent so we have something to train against.
* Observation vector (length 71):
      [0 .. 51]   – 52-length one-hot card encoding
                    (hole cards + board cards that are visible)
      [52]        – agent's normalised stack
      [53]        – opponent's normalised stack
      [54]        – normalised pot size
      [55]        – which betting round (0-3)
      [56 .. 61]  – opponent's last action (one-hot, 6 actions)
      [62 .. 66]  – number of community cards dealt (one-hot, 0-5)
      [67 .. 71]  – placeholder / future features (zeros for now)
* Action space: Discrete(6)  →  fold / check / call / raise_quarter /
                                 raise_half / raise_pot
* A legal-action mask is passed inside `info` every step so the PPO
  network can zero-out illegal moves before sampling.
"""

import random
from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces
from pokerkit import Automation, NoLimitTexasHoldem

from bot import PokerBot


# ── card encoding helpers ────────────────────────────────────────────
RANKS = "23456789TJQKA"
SUITS = "cdhs"
CARD_TO_IDX: dict[str, int] = {
    r + s: i * 4 + j
    for i, r in enumerate(RANKS)
    for j, s in enumerate(SUITS)
}          # e.g. "2c"->0, "2d"->1, … "As"->51


def cards_to_vector(cards: list[str]) -> np.ndarray:
    """Return a 52-dim one-hot vector for a list of card strings."""
    vec = np.zeros(52, dtype=np.float32)
    for c in cards:
        vec[CARD_TO_IDX[c]] = 1.0
    return vec


# ── environment ──────────────────────────────────────────────────────
class PokerEnv(gym.Env):
    """
    Single-agent heads-up No-Limit Texas Hold'em environment.

    Parameters
    ----------
    buy_in   : float   – starting stack for both players
    sb       : float   – small blind
    bb       : float   – big blind
    """

    metadata = {"render_modes": []}

    # action indices
    FOLD           = 0
    CHECK          = 1
    CALL           = 2
    RAISE_QUARTER  = 3
    RAISE_HALF     = 4
    RAISE_POT      = 5

    def __init__(self, buy_in: float = 75.0, sb: float = 5.0, bb: float = 10.0):
        super().__init__()
        self.buy_in = buy_in
        self.sb = sb
        self.bb = bb

        # Gymnasium required spaces
        self.observation_space = spaces.Box(
            low=0.0, high=1.0, shape=(72,), dtype=np.float32
        )
        self.action_space = spaces.Discrete(PokerBot.NUM_ACTIONS)

        # PokerBot instances (used for reward / logging)
        self.agent  = PokerBot("Agent")
        self.opp    = PokerBot("Opponent")

        # PokerKit state (initialised in reset)
        self.state: Any = None
        self.done  = True

    # ── public API ───────────────────────────────────────────────────
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        self._new_hand()
        obs  = self._build_obs()
        info = {"legal_mask": self._legal_mask()}
        return obs, info

    def step(self, action: int):
        # If it's the opponent's turn first (e.g. pre-flop SB acts
        # first in heads-up), let the random opponent act until it's
        # the agent's turn.
        self._maybe_run_opponent()

        # Execute the agent's action
        self._execute_action(action, player=0)

        # If the hand isn't over, let the opponent respond
        if not self.state.actor_index == 0 and not self._hand_over():
            self._maybe_run_opponent()

        # Check if hand is finished
        reward = 0.0
        done   = False
        if self._hand_over():
            reward = self._resolve_hand()
            done   = True
            self.done = True

        obs  = self._build_obs()
        info = {"legal_mask": self._legal_mask()}
        truncated = False
        return obs, reward, done, truncated, info

    # ── internal: hand lifecycle ─────────────────────────────────────
    def _new_hand(self):
        """Create a fresh PokerKit state and deal hole cards."""
        # Reset stacks to buy-in for simplicity (one hand per episode)
        self.agent.cash_val = self.buy_in
        self.opp.cash_val   = self.buy_in

        self.state = NoLimitTexasHoldem.create_state(
            (
                Automation.ANTE_POSTING,
                Automation.BET_COLLECTION,
                Automation.BLIND_OR_STRADDLE_POSTING,
                Automation.CARD_BURNING,
                Automation.HOLE_CARDS_SHOWING_OR_MUCKING,
                Automation.HAND_KILLING,
                Automation.CHIPS_PUSHING,
                Automation.CHIPS_PULLING,
            ),
            True,                           # uniform antes
            0,                              # antes (none)
            (self.sb, self.bb),             # blinds
            self.bb,                        # min bet
            (self.buy_in, self.buy_in),     # starting stacks
            2,                              # num players
        )

        # Deal 2 hole cards to each player
        self.state.deal_hole(self._random_hand())   # player 0 (agent)
        self.state.deal_hole(self._random_hand())   # player 1 (opp)
        self.done = False

    # ── internal: opponent logic ─────────────────────────────────────
    def _maybe_run_opponent(self):
        """Let the random opponent act whenever it's their turn."""
        while (
            not self._hand_over()
            and self.state.actor_index == 1
        ):
            self._execute_action(self._random_action(), player=1)

    def _random_action(self) -> int:
        """Simple random policy for the opponent."""
        mask = self._legal_mask()
        legal = [i for i, v in enumerate(mask) if v]
        return random.choice(legal)

    # ── internal: action execution ───────────────────────────────────
    def _execute_action(self, action: int, player: int):
        """Translate a discrete action index into a PokerKit call."""
        try:
            if action == self.FOLD:
                self.state.fold()

            elif action == self.CHECK:
                self.state.check_or_call()   # PokerKit unifies check/call

            elif action == self.CALL:
                self.state.check_or_call()

            elif action in (self.RAISE_QUARTER, self.RAISE_HALF, self.RAISE_POT):
                pot   = self._current_pot()
                stack = self.state.stacks[player]
                multiplier = {
                    self.RAISE_QUARTER: 0.25,
                    self.RAISE_HALF:    0.50,
                    self.RAISE_POT:     1.00,
                }[action]
                raise_amount = pot * multiplier
                # The amount passed to complete_bet_or_raise_to is the
                # *total* bet size, not the increment.  We add the
                # current bet the player has already put in this round.
                current_bet = self.state.bets[player]
                target = current_bet + raise_amount
                # Clamp to player's stack (all-in)
                target = min(target, stack)
                # PokerKit requires target >= min raise; clamp up
                target = max(target, self.state.min_completion_raising_to_amount or target)
                self.state.complete_bet_or_raise_to(target)

            # After a betting action the board may need dealing (flop/turn/river).
            # PokerKit automations handle card_burning but we must
            # manually deal_board when the phase advances.
            self._deal_board_if_needed()

        except Exception:
            # If the action is illegal PokerKit raises; fall back to check/call
            try:
                self.state.check_or_call()
            except Exception:
                pass   # truly stuck – hand will resolve

    # ── internal: board dealing ──────────────────────────────────────
    def _deal_board_if_needed(self):
        """Deal community cards when PokerKit expects them."""
        if self._hand_over():
            return
        # PokerKit tells us how many board cards are expected
        board_cards_expected = getattr(self.state, 'board_cards', [])
        # If the state is waiting for board dealing, do it
        if hasattr(self.state, 'can_deal_board') and self.state.can_deal_board():
            # deal_board expects a string of cards; use random cards
            # (PokerKit shuffles internally when we pass None-style)
            cards_needed = self.state.board_cards_to_deal or 3   # default flop
            card_str = self._random_cards(cards_needed)
            self.state.deal_board(card_str)

    # ── internal: observation ────────────────────────────────────────
    def _build_obs(self) -> np.ndarray:
        obs = np.zeros(72, dtype=np.float32)

        # [0..51] – one-hot cards (hole + board)
        visible_cards: list[str] = []
        # Agent's hole cards
        if self.state.hole_cards and self.state.hole_cards[0]:
            visible_cards += [str(c) for c in self.state.hole_cards[0]]
        # Board cards
        if self.state.board_cards:
            visible_cards += [str(c) for c in self.state.board_cards]
        obs[0:52] = cards_to_vector(visible_cards)

        # [52] agent stack (normalised)
        obs[52] = self.state.stacks[0] / self.buy_in
        # [53] opponent stack (normalised)
        obs[53] = self.state.stacks[1] / self.buy_in
        # [54] pot (normalised)
        obs[54] = self._current_pot() / (2 * self.buy_in)
        # [55] betting round  0=preflop 1=flop 2=turn 3=river
        obs[55] = self._betting_round() / 3.0
        # [56..61] – opponent last action one-hot (zeros if unknown)
        # (tracked externally; placeholder here)
        # [62..66] – number of community cards one-hot
        n_board = len(self.state.board_cards) if self.state.board_cards else 0
        if n_board <= 5:
            obs[62 + n_board] = 1.0

        return obs

    # ── internal: legal action mask ──────────────────────────────────
    def _legal_mask(self) -> list[int]:
        """
        Return [0 or 1] * 6.  The PPO wrapper uses this to mask
        probabilities before sampling an action.
        """
        mask = [0, 0, 0, 0, 0, 0]
        if self._hand_over():
            mask[self.CHECK] = 1          # dummy; env is done
            return mask

        # Determine what PokerKit allows
        can_call  = self.state.can_check_or_call()
        can_raise = self.state.can_complete_bet_or_raise_to()
        # Fold is always legal when it's your turn
        mask[self.FOLD]  = 1

        if can_call:
            # If no outstanding bet → check; else → call
            if self.state.bets[0] >= (self.state.bets[1] if len(self.state.bets) > 1 else 0):
                mask[self.CHECK] = 1
            else:
                mask[self.CALL] = 1

        if can_raise:
            mask[self.RAISE_QUARTER] = 1
            mask[self.RAISE_HALF]    = 1
            mask[self.RAISE_POT]     = 1

        return mask

    # ── internal: hand resolution ────────────────────────────────────
    def _resolve_hand(self) -> float:
        """
        Figure out who won and return the reward for the agent.
        """
        # PokerKit updates stacks automatically via CHIPS_PUSHING
        agent_final = self.state.stacks[0]
        opp_final   = self.state.stacks[1]

        if agent_final > self.buy_in:
            won = agent_final - self.buy_in
            self.agent.record_win(won)
            return won                   # positive reward
        elif agent_final < self.buy_in:
            lost = self.buy_in - agent_final
            self.agent.record_loss(lost)
            return -lost                 # negative reward
        else:
            return 0.0                   # push

    # ── internal: utility ────────────────────────────────────────────
    def _hand_over(self) -> bool:
        """True when PokerKit considers the hand finished."""
        # PokerKit sets actor_index to None when no one can act
        return self.state.actor_index is None

    def _current_pot(self) -> float:
        """Sum of all bets currently on the table."""
        return float(sum(self.state.bets)) if self.state.bets else 0.0

    def _betting_round(self) -> int:
        """0=preflop, 1=flop, 2=turn, 3=river based on board size."""
        n = len(self.state.board_cards) if self.state.board_cards else 0
        if   n == 0: return 0
        elif n == 3: return 1
        elif n == 4: return 2
        else:        return 3

    @staticmethod
    def _random_hand() -> str:
        """Generate a random 2-card hand string like 'AhKs'."""
        deck = [r + s for r in RANKS for s in SUITS]
        cards = random.sample(deck, 2)
        return "".join(cards)

    @staticmethod
    def _random_cards(n: int) -> str:
        """Generate n random cards as a single string."""
        deck = [r + s for r in RANKS for s in SUITS]
        cards = random.sample(deck, n)
        return "".join(cards)
