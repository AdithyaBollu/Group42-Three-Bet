"""
play.py
-------
Load a trained PPO model and watch it play hands against the random
opponent.  Prints every decision step-by-step so you can see *why*
the bot is making each move.

Usage
-----
    python play.py                       # plays 10 hands
    python play.py --hands 50            # plays 50 hands
    python play.py --model my_model      # load a different .zip
"""

import argparse
from stable_baselines3 import PPO
from poker_env import PokerEnv
from bot import PokerBot


ACTION_NAMES = PokerBot.ACTIONS   # ["fold","check","call","raise_quarter","raise_half","raise_pot"]


def play(model_path: str = "poker_ppo_model", num_hands: int = 10):
    # ── load model ───────────────────────────────────────────────────
    print(f"Loading model from  {model_path}.zip …")
    model = PPO.load(model_path)

    env = PokerEnv()
    total_reward = 0.0
    wins = losses = 0

    for hand_num in range(1, num_hands + 1):
        print("\n" + "=" * 50)
        print(f"  HAND {hand_num}")
        print("=" * 50)

        obs, info = env.reset()
        done      = False
        step      = 0

        while not done:
            # Get action + action probabilities from the policy
            action, _ = model.predict(obs, deterministic=False)
            action    = int(action)

            # Pretty-print the decision
            step += 1
            print(f"\n  [Step {step}] Agent picks: {ACTION_NAMES[action].upper()}")

            # Show a bit of context
            if env.state and env.state.hole_cards and env.state.hole_cards[0]:
                hole = [str(c) for c in env.state.hole_cards[0]]
                print(f"           Hole cards : {hole}")
            if env.state and env.state.board_cards:
                board = [str(c) for c in env.state.board_cards]
                print(f"           Board      : {board}")
            print(f"           Pot        : ${env._current_pot():.2f}")
            print(f"           Stacks     : Agent ${env.state.stacks[0]:.2f} | "
                  f"Opp ${env.state.stacks[1]:.2f}")

            obs, reward, done, truncated, info = env.step(action)

        # ── hand summary ─────────────────────────────────────────────
        total_reward += reward
        if reward > 0:
            wins += 1
            outcome = f"WON  +${reward:.2f}"
        elif reward < 0:
            losses += 1
            outcome = f"LOST -${abs(reward):.2f}"
        else:
            outcome = "PUSH  $0.00"

        print(f"\n  ── Result : {outcome} ──")

    # ── session summary ──────────────────────────────────────────────
    print("\n" + "=" * 50)
    print("  SESSION SUMMARY")
    print("=" * 50)
    print(f"  Hands played  : {num_hands}")
    print(f"  Wins          : {wins}")
    print(f"  Losses        : {losses}")
    print(f"  Pushes        : {num_hands - wins - losses}")
    print(f"  Total reward  : ${total_reward:+.2f}")
    print(f"  Avg reward    : ${total_reward / num_hands:+.2f} / hand")


# ── CLI ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Watch the trained poker bot play.")
    parser.add_argument("--model", default="poker_ppo_model", help="Model filename (no .zip)")
    parser.add_argument("--hands", type=int, default=10, help="Number of hands to play")
    args = parser.parse_args()
    play(model_path=args.model, num_hands=args.hands)
